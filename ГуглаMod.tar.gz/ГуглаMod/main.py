import pygame
import os

player = pygame.image.load("img/p.png")
cactusi = pygame.image.load("img/c.png")
ground = pygame.image.load("img/road.png")

timer = 0
world = 1
clock = pygame.time.Clock()
fps = 120

width = 1200
height = 700

window = pygame.display.set_mode((width, height))

def world1():
    window.fill((255,255,255))
    c_g.update()
    c_g.draw(window)
    road_group.update()
    road_group.draw(window)
    p_group.update()
    p_group.draw(window)
    pygame.display.update()

class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = player
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = 510
        self.jump = False
        self.jump_acceleration = -25
        self.timer_spwn = 0
        self.mask = pygame.mask.from_surface(self.image)
        self.mask_outline = self.mask.outline()
        self.mask_list = []
        self.gravity = 4

    def update(self):
        self.timer_spwn += 1
        if self.timer_spwn / fps > 1:
            cactus = C()
            c_g.add(cactus)
            self.timer_spwn = 0

        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_SPACE]:
            self.jump = True
        if self.jump:
            if self.jump_acceleration <= 25:
                self.rect.y += self.jump_acceleration
                self.jump_acceleration += 1
            else:
                self.jump = False
                self.jump_acceleration = -25
                self.mask_list = []
        for i in self.mask_outline:
            self.mask_list.append((i[0] + self.rect.x, i[1] + self.rect.y))
        self.rect.y += self.gravity

class C(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = cactusi
        self.rect = self.image.get_rect()
        self.rect.x = 1350
        self.rect.y = 500
        self.mask = pygame.mask.from_surface(self.image)
        self.mask_outline = self.mask.outline()
        self.mask_list = []


    def update(self):
        self.rect.x -= 7
        if self.rect.right < 0:
            self.kill()
        self.mask_list = []
        for i in self.mask_outline:
            self.mask_list.append((i[0] + self.rect.x, i[1] + self.rect.y))
        if len(set(self.mask_list) & set(pl.mask_list)) > 0:
            pass

class Ground(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = ground
        self.rect = self.image.get_rect()
        self.rect.x = 0
        self.rect.y = 600
    def update(self):
        if pygame.sprite.spritecollide(self, p_group, False):
            pl.rect.bottom = self.rect.top
            pl.jump = False
            pl.jump_acceleration = -25

c_g = pygame.sprite.Group()

pl = Player()
p_group = pygame.sprite.Group()
p_group.add(pl)

road = Ground()
road_group = pygame.sprite.Group()
road_group.add(road)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()

    if world == 1:
        world1()

    clock.tick(fps)
